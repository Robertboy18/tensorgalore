#!/bin/bash

#SBATCH --time=32:00:00   # walltime
#SBATCH --ntasks=1   # number of processor cores (i.e. tasks)
#SBATCH --nodes=1   # number of nodes
#SBATCH --mem=64G   # memory per CPU core
#SBATCH --gres gpu:1
#SBATCH --partition=gpu
#SBATCH -J "ns_matrix_3_075"   # job name
#SBATCH --mail-user=USERNAME@caltech.edu   # email address
#SBATCH --mail-type=BEGIN
#SBATCH --mail-type=END
#SBATCH --mail-type=FAIL


source /home/USERNAME/.bashrc;

conda activate tensorgalore;

echo $CONDA_PREFIX;

cd /home/USERNAME/work/dev/tensorgalore;

python train_ns_repro_galore.py \
    --distributed.use_distributed False \
    --opt.galore True \
    --opt.save_every None \
    --opt.naive_galore True \
    --opt.galore_rank 0.75 \
    --opt.first_dim_rollup 3 \
    --opt.galore_scale 1.0 \
    --opt.update_proj_gap 200 \
    --opt.resume_from_dir None \
    --opt.galore_warm_restart True \
    --fno.projection_channels 256 \
    --opt.learning_rate 0.0003 \
    --data.train_resolution 128 \
    --data.batch_size 8 \
    --data.test_resolutions [128] \
    --data.test_batch_sizes [8] \
    --data.n_train 10000 \
    --data.n_tests [2000] \
    --data.root "/home/USERNAME/work/data/navier_stokes" \
    --wandb.log True \
    --wandb.entity pino-training \
    --wandb.project tensorgalore \
    --wandb.name ns_128_repro_ranksweep \