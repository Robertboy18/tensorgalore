import h5py
import torch
from pathlib import Path

root_dir = Path("/raid/USER/navier_stokes/ns1024_full/")
full_x = []
full_y = []

# create train dataset
for i in range(1,11):
    pt_data = torch.load(root_dir / f"nsforcing_1024_train{i}.pt")
    print(pt_data["x"].shape)
    full_x.append(pt_data["x"])
    full_y.append(pt_data["y"])

full_x = torch.cat(full_x, dim=0)
full_x = full_x.unsqueeze(1)
print(f"{full_x.shape=}")

full_y = torch.cat(full_y, dim=0)
full_y = full_y.unsqueeze(1)
print(f"{full_y.shape=}")

with h5py.File(root_dir / "nsforcing_1024_train.hdf5", "w") as f:
    f.create_dataset("x", shape=full_x.shape, data=full_x)
    f.create_dataset("y", shape=full_y.shape, data=full_y)

full_x = []
full_y = []

# create test dataset
for i in range(1,3):
    pt_data = torch.load(root_dir / f"nsforcing_1024_test{i}.pt")
    print(pt_data["x"].shape)
    full_x.append(pt_data["x"])
    full_y.append(pt_data["y"])

full_x = torch.cat(full_x, dim=0)
full_x = full_x.unsqueeze(1)
print(f"{full_x.shape=}")

full_y = torch.cat(full_y, dim=0)
full_y = full_y.unsqueeze(1)
print(f"{full_y.shape=}")

with h5py.File(root_dir / "nsforcing_1024_test.hdf5", "w") as f:
    f.create_dataset("x", shape=full_x.shape, data=full_x)
    f.create_dataset("y", shape=full_y.shape, data=full_y)